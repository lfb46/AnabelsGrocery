//
//  glovars.swift
//  AnabelsGrocery
//
//  Created by Liam Bo on 1/7/22.
//

import Foundation


struct glovars {

   
    
    static var categories: [String] = ["Bread", "Dairy", "Pantry", "Fruits and Vegetables", "Nuts", "Pasta, Grains, Beans, Legumes", "Materials", "Packaging", "Drinks", "Meat", "Snacks", "Spices", "Tea", "Tofu, Miso, Eggs"]
    
    static var categoryPhotos: [String] = ["bread.jpg", "milk.jpg","pantry.jpg", "produce.jpeg", "nuts.jpeg", "pasta.jpeg", "Materials.jpeg", "packing.jpeg", "drinks.jpg", "Meat.jpeg", "snacks.jpg", "spices.jpeg", "tea.jpeg", "tofu.jpg"]
    
    static var catNum = 0
    static var recipeNum = 0
    static var RecipeList = ["Overnight Oats", "Margharita Pizza", "Chocolate Lava Cake"]
    static var RecipeImageList = ["oats.jpg", "pizza.jpg", "cake.jpg"]
    
    static var Bread = [["Lettuce", "$5.00", "let.jpg"], ["Carrots", "$12.00", "carrot.jpg"], ["Onions", "$50.00", "onion.jpg"], ["Beets", "$2.00", "beets.jpg"]]
    static var Dairy = [["Milk","$0.00", "milk.jpg"], ["Carrots", "$12.00", "carrot.jpg"]]
    static var Pantry = [["Pantry","$0.00", "pantry.jpg"]]
    static var FruitsandVegs = [["Produce","$0.00", "produce.jpeg"]]
    static var Nut = [["Nuts","$0.00", "nuts.jpeg"]]
    static var Pasta = [["Pasta","$0.00", "pasta.jpeg"]]
    static var Grains = [["Grains","$0.00", "pasta.jpeg"]]
    static var Beans = [["Beans","$0.00", "pasta.jpeg"]]
    static var Legumes = [["Legumes","$0.00", "Materials.jpeg"]]
    static var Materials = [["Packaging","$0.00", "packing.jpeg"]]
    static var Drinks = [["Drinks","$0.00", "drinks.jpg"]]
    static var Meats = [["Meats","$0.00", "Meat.jpeg"]]
    static var Snacks = [["Snacks","$0.00", "snacks.jpg"]]
    static var Spices = [["Spices","$0.00", "spices.jpeg"]]
    static var Tea = [["Tea","$0.00", "tea.jpeg"]]
    static var Tofu = [["Tofu","$0.00", "tofu.jpg"]]
    static var Miso = [["Miso","$0.00", "packing.jpeg"]]
    static var Eggs = [["Eggs","$0.00", "packing.jpeg"]]
    //some have the wrong image since not in the list yet
    


}
